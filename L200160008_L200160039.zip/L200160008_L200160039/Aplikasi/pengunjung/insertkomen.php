<?php include "akses.php" ?>

<html>
	<head>
		<title>Insert komen</title>
	</head>
	<body>
		<?php
		error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
		include "koneksi.php";
		$id_post =$_POST['idart'];
		$komentar = $_POST['komen'];
		$username = $_SESSION['username'];
		$sub = $_POST['sub'];
		
		if($sub){
			$insertkom = "insert into komentar(username_user,id_posting,isi_komentar)
						values('$username','$id_post','$komentar')";
			$jalan = mysqli_query($conn,$insertkom);
				if($jalan){
					header("location:lengkaplogin.php?cmp=$id_post");
				}
		}
		?>
	</body>
</html>