<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
include "koneksi.php";
//echo "$_GET[id_lokasi]";
	$id = $_GET['idnya'];
	$sql = "select * from lokasi where id_lokasi='$id'";
	$carimap = mysqli_query($conn,$sql);
	$cari = mysqli_fetch_array($carimap);
?>
<html>
  <head><title>Lokasi</title>
    <style>
       #map {
        height: 400px;
        width: 100%;
       }
    </style>
  </head>
  <body>
    <h3><?php echo "$cari[nama_lokasi]"; ?></h3>
    <div id="map"></div>
    <script>
      function initMap() {
        var uluru = {lat:<?php echo "$cari[lat]";?> , lng:<?php echo "$cari[lng]"; ?>};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 4,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBg51lFuTlCwaSn9Snm0PLFC2Jnn3dl50g&callback=initMap">
    </script>
  </body>
</html>