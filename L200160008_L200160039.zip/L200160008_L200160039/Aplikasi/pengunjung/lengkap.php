<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
session_start();
$status = $_SESSION['status'];
if($status == "pengunjung"){
	header("location:lengkaplogin.php");
}
?>

<html>
	<head>
		<title>Explore Wonogiri</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><strong><a href="index.php">Explore</a></strong> Wonogiri</h1>
				<nav id="nav">
					<ul>
						<li><a href="../index.php">Home</a></li>
						<li><a href="tentang.php">Tentang</a></li>
						<li><a href="galeri.php">Galeri</a></li>
						<li>|</li>
						<li><a href="../login.php">Login</a></li>
					</ul>
				</nav>
			</header>

			<a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>
			
		<!-- Main -->
			<?php
				error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
				include "koneksi.php";
				$comp = $_GET['cmp'];
				$sql = "select * from posting where id_posting='$comp'";
				$query=mysqli_query($conn,$sql);
				$hasil=mysqli_fetch_array($query);
			?>
			
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major special" >
						<center><h3><?php echo "$hasil[judul_posting]"?></h3></center>
						<p><?php echo "$hasil[tanggal]"?></p>
					</header>

					<img src="<?php echo $hasil['gambar']?>" width="100%" height="100%">
					<p><?php echo "$hasil[isi_posting];"?>
							
		<!-- Menampilkan Komentar -->
		<h3>Komentar</h3>
			<?php
				error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
				include "koneksi.php";
				$kom = $_GET['cmp'];
				$run = "select * from komentar where id_posting = '$kom'";
				$kueri = mysqli_query($conn,$run);
				while($komen=mysqli_fetch_array($kueri)){
			?>
				<blockquote>
					<?php echo "$komen[username_user]";?></br>
					<?php echo "$komen[isi_komentar]";?>
				</blockquote>
			<?php
				}
			?>
		
				</div>
			</section>
			
		
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<ul class="icons">
						<li><a href="http://facebook.com" class="icon fa-facebook"></a></li>
						<li><a href="http://twitter.com" class="icon fa-twitter"></a></li>
						<li><a href="http://instagram.com" class="icon fa-instagram"></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; by NOFA</li>
						<li>Design: <a href="http://templated.co">TEMPLATED</a></li>
						<li>Images: <a href="http://unsplash.com">Unsplash</a></li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>