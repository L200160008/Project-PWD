<?php include "akses.php"?>
<html>
	<head>
		<title>Explore Wonogiri</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><strong><a href="index.html">Explore</a></strong> Wonogiri</h1>
				<nav id="nav">
					<ul>
						<li><a href="indexlogin.php">Home</a></li>
						<li><a href="tentang.php">Tentang</a></li>
						<li><a href="galerilogin.php">Galeri</a></li>
						<li>|</li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</nav>
			</header>

			<a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">

					<center><header class="major special">
						<h2>WONOGIRI SUKSES</h2>
						<p>Wonogiri Kota Gaplek</p>
					</header></center>
					<img src="images/wonogiri.jpg" width="100%" >
					<p><i>Wonogiri, (bahasa Jawa: wanagiri, secara harfiah "Hutan di Gunung"), adalah sebuah daerah kabupaten di Jawa Tengah. 
					Secara geografis lokasi Wonogiri berada di bagian tenggara Provinsi Jawa Tengah. 
					Bagian utara berbatasan dengan Kabupaten Karanganyar dan Kabupaten Sukoharjo, bagian selatan langsung di bibir Pantai Selatan,
					bagian barat berbatasan dengan Wonosari di provinsi Yogyakarta, Bagian timur berbatasan langsung dengan Provinsi Jawa Timur, 
					yaitu Kabupaten Ponorogo dan Kabupaten Pacitan. Ibu kotanya terletak di Wonogiri Kota. Luas kabupaten ini 1.822,37 km² dengan populasi 1,5 juta jiwa.</i></p>
					<p><b>Sejarah</b></br>
					Sejarah berdirinya Kabupaten Wonogiri dimulai dari embrio "kerajaan kecil" di bumi Nglaroh Desa Pule Kecamatan Selogiri. 
					Di daerah inilah dimulainya penyusunan bentuk organisasi pemerintahan yang masih sangat terbatas dan sangat sederhana, 
					dan dikemudian hari menjadi simbol semangat pemersatu perjuangan rakyat. Inisiatif untuk menjadikan Wonogiri (Nglaroh) sebagai basis perjuangan Raden Mas Said, 
					adalah dari rakyat Wonogiri sendiri ( Wiradiwangsa) yang kemudian didukung oleh penduduk Wonogiri pada saat itu.
					Mulai saat itulah Ngalroh (Wonogiri) menjadi daerah yang sangat penting, yang melahirkan peristiwa-peristiwa bersejarah di kemudian hari. 
					Tepatnya pada hari Rabu Kliwon tanggal 3 Rabi'ul awal (Mulud) Tahun Jumakir, Windu Senggoro: Angrasa retu ngoyang jagad atau 1666, 
					dan apabila mengikuti perhitungan masehi maka menjadi hari Rabu Kliwon tanggal 19 Mei 1741 ( Kahutaman Sumbering Giri Linuwih), 
					Ngalaroh telah menjadi kerajaan kecil yang dikuatkan dengan dibentuknya kepala punggawa dan patih sebagai perlengkapan (institusi pemerintah) 
					suatu kerajaan walaupun masih sangat sederhana. Masyarakat Wonogiri dengan pimpinan Raden Mas Said selama penjajajahan Belanda telah pula menunjukkan reaksinya menentang kolonial.
					Jerih payah pengeran Samber Nyawa ( Raden Mas Said ) ini berakhir dengan hasil sukses terbukti beliau dapat menjadi Adipati di Mangkunegaran dan Bergelar Kanjeng Gusti Pangeran Adipati Arya ( KGPAA) Mangkunegoro I). 
					Peristiwa tersebut diteladani hingga sekarang karena berkat sikap dan sifat kahutaman ( keberanian dan keluhuran budi ) perjuangan pemimpin, pemuka masyarakat yang selalu didukung semangat kerja sama seluruh rakyat di Wilayah Kabupaten Wonogiri.
					Pemerintahan
					Saat ini (pada tahun 2018) Kabupaten Wonogiri dipimpin oleh Bupati Joko Sutopo. 
					Dalam jalannya roda pemerintahan, bertumpu pada semboyan Wonogiri SUKSES yang merupakan singkatan dari STABILITAS, UNDANG-UNDANG, KOORDINASI, SASARAN, EVALUASI, dan SEMANGAT JUANG.</p>
					<p><b>Pariwisata</b></br>
					Di Kabupaten Wonogiri terdapat banyak tempat wisata yang bisa dikunjungi. Baik wisata spiritual, petualangan, wisata alam dan lain sebagainya. Di antaranya obyek wisata Waduk Gajah Mungkur, wisata ganthole.
					Terdapat sebuah situs bersejarah bernama "Kahyangan" di dusun Dlepih, Tirtomoyo, yang jaraknya kurang lebih 47 km dari ibu kota kabupaten Wonogiri.
					Dari Kota Wonogiri, pengunjung bisa naik bus dari terminal bus giriwono dan naik minibus dari dekat ponten (dekat Kantor Badan Pertanahan), jurusan Tirtomoyo. Dari Tirtomoyo, bisa naik angdes jurusan Kahyangan atau Sukarjo. Sampai sekarang belum ada angdes yang bisa masuk sampai Kahyangan, sehingga harus dilanjutkan jalan kaki sekitar 1 Km. Pengunjung berkendaraan bisa langsung sampai ke tempat parkir Kahyangan.
					Sebetulnya desa Taman dulunya merupakan sentra batik tulis, yang produknya banyak disetorkan ke Solo, untuk diproses lanjut. Banyak warga desa yang bergerak di bidang yang berhubungan dengan batik, baik sebagai pembatik, pembuat patron, pemasok kain mori. Akan tetapi, seiring dengan diperkenalkannya teknik pembuatan genting press, yang hasilnya cepat diperoleh, maka semakin lama industri batik semakin tergeser.
					Sesampai di Kahyangan, pengunjung akan mendapati goa yang terletak di atas kedung. Konon, tempat itu sebagai tempat bersemedinya Danang Suto Wijoyo, atau yang dikenal dengan Panembahan Senopati, raja pertama kerajaan Mataram Islam. Selain itu, terdapat pula air terjun, dan puncak Kahyangan yang konon merupakan tempat di mana Sutowijoyo menemuai Kanjeng Ratu Kidul, sehingga bagi yang percaya tahyul, dilarang memakai baju yang berwarna hijau.
					Tempat itu sangat ramai di malam menjelang pergantian tahun Jawa (bulan Suro). Banyak pendatang dari luar daerah, terutama dari daerah Yogyakarta, untuk bertirakatan di sana. Di hari-hari biasa, terutama malam Jumat Kliwon, biasanya banyak dikunjungi orang-orang dari luar daerah, yang mengadakan syukuran atas keberhasilan yang telah dicapai di tempat perantaunnya, dengan mengundang warga sekitar.
					Tempat Wisata Lain:</br>
					• Pantai Sembukan</br>
					• Pantai Nampu</br>
					• Musium Wayang Kulit</br>
					• Cagar Alam Danalaya</br>
					• Gua Ngantap</br>
					• Sendang Siwani</br>
					• Gua Putri Kencono</br>
					• Gua Musium karst</br>
					• Jala karamba
					</p>
					<p><b>Makanan khas</b></br>
					Dulu terkenal dengan "tiwul" tapi sekarang sudah jarang dijumpai "Ngaso angkringan",Beberapa jenis makanan khas tersedia di Wonogiri. Kacang Mede adalah makanan yang berasal dari biji buah jambu mede (jambu mete) yang memang banyak terdapat di wilayah Wonogiri. 
					Emping adalah makanan yang berasal dari biji buah melinjo. Biji buah dikupas, lalu ditumbuk sampai berbentuk lempengan kecil. Kedua jenis makanan ini disajikan setelah terlebih dahulu digoreng sampai kecoklatan. Cabuk adalah makanan yang berasal dari biji wijen yang dicampur dengan bumbu masak. Berbentuk pasta, warna hitam, terbungkus daun pisang.
					Juga ada makanan dari singkong yang disebut "Pindang", ini berasal dari tepung singkong yang dimasak dengan Daging Kambing, yang terkenal di sebelah Barat Lapangan Kecamatan Ngadirojo. Saat pagi hari juga sering dapat dijumpai Kue Serabi di beberapa tempat di dekat Pasar Kota Wonogiri.
					Makanan khas lain adalah Bakso dan Mie Ayam Wonogiri yang memiliki citarasa khas, makanya di Jakarta banyak sekali tukang bakso atau mie ayam dari Wonogiri, namun sayang kalau membeli di Jakarta rasanya jauh tidak enak. Mie Ayam yang terkenal adalah Mie Ayam Pak Tukang, Mie Ayam Pak Sabar, Mie Ayam Pak Brewok, Mie Ayam dan Bakso Mas Bentoel. Bakso yang terkenal Bakso Malvinas, Bakso Gajah Mungkur dan Bakso Titoti.
					Selain itu pada malam hari, banyak juga pedagang makanan lesehan yang tersebar sepanjang jalan-jalan di Wonogiri, dengan bermacam-macam jenis makanan, yang terkenal antara lain seperti Sari Laut & Pecel Lele "Mas Gendut", Soto mbak Bunder, Gudeg & Nasi Liwet Bu SAMAN GI (depan toko Baru), Mie Rebus Jawa Pak BAGONG (terminal lama), Cap Cay depan Gereja GKI.
					Pusat jajanan khas Wonogiri ada di dekat kantor Kecamatan Selogiri, kurang lebih 5 km dari pusat Kota Wonogiri ke arah Kota Surakarta. Di pusat Kota Wonogiri, terdapat beberapa toko yang menyediakan makanan khas, salah satu di antaranya adalah Toko Sari Roso. Selain itu, oleh-oleh khas Wonogiri juga bisa diperoleh di kios-kios yang banyak terdapat di pasar Wonogiri, salah satu yang cukup banyak dikunjungi pembeli adalah kios Bu Darmo.
					Sebagai tambahan tentang makanan khas yang disebut "CABUK", akan lebih nikmat apabila disantap bersama-sama dengan "Gudangan" yakni makanan yang berupa sayur-sayuran yang telah direbus dicanpur dengan samabal dari parutan kelapa.
					</p>
					<p><b>Pertanian</b></br>
					Secara umum, wilayah Kabupaten Wonogiri terbagi menjadi 2 kelompok. Wilayah selatan yang membentang dari perbatasan Kabupaten Pacitan (Provinsi Jawa Timur) sampai perbatasan Kabupaten Gunung Kidul (Provinsi DIY) adalah wilayah yang kaya dengan pegunungan kapur. Pada area ini tidak banyak yang bisa dilakukan kecuali berladang (palawija) dengan ketergantungan pada curah hujan. Curah hujan per tahun berada pada level yang rendah. 
					Area ini memiliki banyak sumber air dalam, dimana sampai saat ini masih belum bisa dimanfaatkan. Di beberapa tempat, dapat dijumpai sawah dengan jenis padi khusus (padi Gogo Rancah), ditanam pada media tanah yang sengaja diurugkan di atas batuan kapur.
					Dari area timur berbatasan dengan Kabupaten Ponorogo (Jawa Timur), area utara berbatasan dengan Kabupaten Karanganyar, dan area barat berbatasan dengan berbatasan dengan Kabupaten Sukoharjo, memiliki karakteristik yang relatif mendukung. Curah hujan yang cukup, dengan dukungan irigasi yang optimal, mampu mendukung budaya pertanian yang lebih menjanjikan. Hamparan sawah banyak dijumpai pada area ini.
					Perkebunan
					Secara umum, seluruh wilayah Kabupaten Wonogiri masih mampu memberikan hasil pertanian dan perkebunan yang melimpah. Singkong (manihot), coklat (cacao), kacang mede, emping melinjo, sayur-sayuran, merupakan contoh hasil perkebunan yang relatif baik.
					</p>
					<p><b>Telekomunikasi</b></br>
					Perkembangan layanan telekomunikasi telah pula membantu Kabupaten Wonogiri untuk bisa mendapatkan layanan telekomunikasi yang baik.
					PT. Telekomunikasi Indonesia telah menempatkan satu kantor layanan. Dengan STO (Sentral Telepon Otomatis) berkapasitas lebih dari 3000 nomor, 
					masih didukung dengan ekspansi operator selular, layanan telekomunikasi telah mampu dinikmati. Hampir semua operator (Telkomsel, Excelcom, Indosat) 
					telah memasang perangkat BTS (Base Transceiver Station) di pusat kota Wonogiri. Telkomsel telah merambah beberapa kota kecamatan, disusul juga BTS dari Mobil8(fren).
					</p>
					<p><b>Transportasi</b></br>
					Entah sejak kapan orang wonogiri suka merantau. Yang jelas di berbagai pulau di Indonesia banyak dijumpai orang wonogiri. 
					Di rantau memiliki berbagai profesi, umumnya menjadi pedagang. Di jawa sendiri, terutama di Jakarta juga banyak orang wonogiri. 
					Hal inilah yang mendorong tumbuhnya industri transportasi di Wonogiri.</p>
					
					<p><b>Bus</b></br>
					Di Wonogiri banyak kita jumpai pengusaha bus.Disamping dengan kota-kota terdekat, Perusahaan bus terbanyak mengambil rute Wonogiri-Jakarta. Sehingga siapun yang keluar wasuk kota Wonogiri tidak perlu risau dengan adanya transportasi bus ini. 
					Bus yang mengambil rute Wonogiri jakarta dapat kami sebutkan diantaranya: Sedyo mulyo, Tunggal dara, Tunggal daya, gunung mulya, timbul jaya, serba mulya, ismo, dll.</p>
					
					<p><b>Kereta</b></br>
					Dengan Kereta Wonogiri hanya terhubung dengan Solo. 
					Biasanya kereta penumpang hanya 1 kali masuk dan keluar Wonogiri menuju arah kota Solo.</p>

					<p><b>Kesehatan</b></br>
					Tersedia beberapa layanan rumah sakit, di antaranya:</br>
					• Rumah Sakit Umum Wonogiri</br>
					• Rumah Sakit Marga Husada</br>
					• Rumah Sakit Medika Mulya</br>
					• Rumah Sakit PKU Muhammadiah</br>
					• Rumah Sakit Bersalin Fitri Candra</br>
					• Rumah Sakit Anak Astrini
					</p>
				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<ul class="icons">
						<li><a href="#" class="icon fa-facebook"></a></li>
						<li><a href="#" class="icon fa-twitter"></a></li>
						<li><a href="#" class="icon fa-instagram"></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled</li>
						<li>Design: <a href="http://templated.co">TEMPLATED</a></li>
						<li>Images: <a href="http://unsplash.com">Unsplash</a></li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>