<?php include "akses.php"?>
<html>
	<head>
		<title>Explore Wonogiri</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><strong><a href="index.html">Explore</a></strong> Wonogiri</h1>
				<nav id="nav">
					<ul>
						<li><a href="indexlogin.php">Home</a></li>
						<li><a href="tentanglogin.php">Tentang</a></li>
						<li><a href="galerilogin.php">Galeri</a></li>
						<li>|</li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</nav>
			</header>

			<a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>
			
	<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">
						<?php
							error_reporting(E_ALL ^ E_NOTICE);
							include "koneksi.php";
							$sql = "select * from posting";
							$query = mysqli_query($conn,$sql);
							while($data=mysqli_fetch_array($query)){
						?>
								<center><h3><?php echo "$data[judul_posting]"?></h3></center>
								<p><?php echo "$data[tanggal]"?></p>
								<img src="<?php echo $data[gambar]?>" width="100%" height="100%">
								<p><?php echo substr($data[isi_posting],0,400);
								echo "....<a href='lengkaplogin.php?cmp=$data[id_posting]'>Baca Selengkapnya</a>";
							}
						?>
						</p>
						

				</div>
			</section>
			
	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<ul class="icons">
						<li><a href="http://facebook.com" class="icon fa-facebook"></a></li>
						<li><a href="http://twitter.com" class="icon fa-twitter"></a></li>
						<li><a href="http://instagram.com" class="icon fa-instagram"></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; by NOFA</li>
						<li>Design: <a href="http://templated.co">TEMPLATED</a></li>
						<li>Images: <a href="http://unsplash.com">Unsplash</a></li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>