<?php include "akses.php"?>
<html>
	<head>
		<title>Explore Wonogiri</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="landing">

		<!-- Header -->
			<header id="header" class="alt">
				
				<nav id="nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="tentanglogin.php">Tentang</a></li>
						<li><a href="galerilogin.php">Galeri</a></li>
						<li>|</li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</nav>
			</header>

			<a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>

		<!-- Banner -->
			<section id="banner">
				<h2>Explore Wonogiri</h2>
				<p>Selamat Datang !<br /> Cari referensi tempat liburanmu disini.</p>
				<ul class="actions">
					<li><a href="galerilogin.php" class="button special big">Mulai</a></li>
				</ul>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<ul class="icons">
						<li><a href="http://facebook.com" class="icon fa-facebook"></a></li>
						<li><a href="http://twitter.com" class="icon fa-twitter"></a></li>
						<li><a href="http://instagram.com" class="icon fa-instagram"></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; by NOFA</li>
						<li>Design: <a href="http://templated.co">TEMPLATED</a></li>
						<li>Images: <a href="http://unsplash.com">Unsplash</a></li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>