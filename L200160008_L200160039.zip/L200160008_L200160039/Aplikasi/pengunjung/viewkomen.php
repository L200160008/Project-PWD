<!-- Menampilkan Komentar -->
<?php
session_start();
	error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
	$run = "select * from komentar where id_posting = '$comp'";
	$kueri = mysqli_query($conn,$run);
		while($komen=mysqli_fetch_array($kueri)){
		include "koneksi.php";
			?>
			<blockquote>
				<b><?php echo "$komen[username_user]";?></b></br>
				<?php echo "$komen[isi_komentar]";?>
			</blockquote>
			<?php
		}
?>