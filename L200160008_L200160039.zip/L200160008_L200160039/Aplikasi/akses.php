<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
session_start();
$status = $_SESSION['status'];
if($status != "pengunjung"){
	echo '<script language="javascript">alert("Anda harus Login!"); document.location="../login.php";</script>';
}
?>