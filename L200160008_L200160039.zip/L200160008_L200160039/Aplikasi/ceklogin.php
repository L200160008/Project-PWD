<?php
include "koneksi.php";
session_start();
$username = $_POST['username'];
$password = $_POST['password'];
$submit = $_POST['submit'];
if($submit){
	$sql = "select * from user where username='$username' and password='$password' ";
	$query=mysqli_query($conn,$sql);
	$hasil = mysqli_fetch_array($query);
	if($hasil['status']=="admin"){
		$_SESSION['username']= $hasil['username'];
		$_SESSION['nama']= $hasil['nama_lengkap'];
		$_SESSION['status']= $hasil['status'];
		?>
		<script>alert("Selamat Datang! Anda Login sebagai Admin");document.location='admin/index.php';</script>
		<?php
	}else if($hasil['status']=="pengunjung"){
		$_SESSION['username']= $hasil['username'];
		$_SESSION['nama']= $hasil['nama_lengkap'];
		$_SESSION['status']= $hasil['status'];
		?>
		<script>alert("Selamat Datang!");document.location='pengunjung/galerilogin.php';</script>
		<?php
	}else{
		?>
		<script>alert("Username dan Password Salah!");document.location='login.php';</script>
		<?php
	}
}
?>