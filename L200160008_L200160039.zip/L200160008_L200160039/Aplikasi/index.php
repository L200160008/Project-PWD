<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
session_start();
$status = $_SESSION['status'];
if($status == "pengunjung"){
	header("location:pengunjung/indexlogin.php");
}elseif($status=="admin"){
	header("location:admin/index.php");
}
?>

<html>
	<head>
		<title>Explore Wonogiri</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="pengunjung/assets/css/main.css" />
	</head>
	<body class="landing">

		<!-- Header -->
			<header id="header" class="alt">
				
				<nav id="nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="pengunjung/tentang.php">Tentang</a></li>
						<li><a href="pengunjung/galeri.php">Galeri</a></li>
						<li>|</li>
						<li><a href="login.php">Login</a></li>
					</ul>
				</nav>
			</header>

			<a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>

		<!-- Banner -->
			<section id="banner">
				<h2>Explore Wonogiri</h2>
				<p>Selamat Datang !<br /> Cari referensi tempat liburanmu disini.</p>
				<ul class="actions">
					<li><a href="pengunjung/galeri.php" class="button special big">Mulai</a></li>
				</ul>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<ul class="icons">
						<li><a href="http://facebook.com" class="icon fa-facebook"></a></li>
						<li><a href="http://twitter.com" class="icon fa-twitter"></a></li>
						<li><a href="http://instagram.com" class="icon fa-instagram"></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; by NOFA</li>
						<li>Design: <a href="http://templated.co">TEMPLATED</a></li>
						<li>Images: <a href="http://unsplash.com">Unsplash</a></li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="pengunjung/assets/js/jquery.min.js"></script>
			<script src="pengunjung/assets/js/skel.min.js"></script>
			<script src="pengunjung/assets/js/util.js"></script>
			<script src="pengunjung/assets/js/main.js"></script>

	</body>
</html>