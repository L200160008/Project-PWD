<?php include('aksesadmin.php'); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Ubah Tempat Wisata</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
	<div class="container">
        <div class="row text-center ">
            <div class="col-md-12">
                <br /><br />
                <h2> Masukkan Data Tempat Wisata</h2>
                <br/>
				<br/>
            </div>
        </div>
		<div class="row ">
                <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
				<a href="post.php" class="btn btn-danger">Kembali</a>
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Masukkan Data
                        </div>
                        <div class="panel-body">
                            <h3></h3>
                            <form method="post" name="insert" action="insert.php" enctype="multipart/form-data">
									
									<div class="form-group">
                                        <label>Judul</label>
										<input class="form-control" name="judul">
                                    </div>
									<hr>
									<div class="form-group">
                                        <label>Tanggal</label>
										<input class="form-control" name="tgl">
                                    </div>
									<hr>
									<div class="form-group">
                                        <label>Gambar</label>
                                        <input type="file" name="gambar">
                                    </div>
									<hr>
									<div class="form-group">
                                            <label>Isi</label>
                                            <textarea class="form-control" rows="3" name="isi"></textarea>
                                    </div>
								
								</div>
								<div class="panel-footer">
								<input type="submit" class="btn btn-primary" name="submit" value="Submit">
								<input type="reset" class="btn btn-default" name="reset" value="Reset">
							</form>
							<?php
								error_reporting(E_ALL ^ E_NOTICE);
								$un = $_SESSION['username'];
								$judul = $_POST['judul'];
								$tgl = $_POST['tgl'];
								$folder = "images/";
								$nama_gambar = $_FILES['gambar']['name'];
								$gambar = $folder.$nama_gambar;
								$isi = $_POST['isi'];
								$submit = $_POST['submit'];
								
								if($submit){
									include "koneksi.php";
									$sql = "insert into posting(id_posting,username_user,judul_posting,tanggal,gambar,isi_posting)
									values('','$un','$judul','$tgl','$gambar','$isi')";
									$run = mysqli_query($conn,$sql);
									move_uploaded_file($_FILES["gambar"]["tmp_name"],$gambar);
									if($run){
										?>
										<script>alert("Data Berhasil Dimasukkan");
										document.location = 'post.php'
										</script>
										<?php
									}
								}
								?>
                        </div>
                    </div>
                </div>
        </div>
		<!-- /. ROW  -->
		</div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>