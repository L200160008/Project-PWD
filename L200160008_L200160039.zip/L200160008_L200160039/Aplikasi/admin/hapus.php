<?php
include "koneksi.php";
$del = $_GET['del'];
$sql = "delete from posting where id_posting = '$del'";
$query = mysqli_query($conn,$sql);
if($query){
	?>
	<script>alert("Data Berhasil Dihapus");
	document.location="post.php"
	</script>
	<?php
}
?>