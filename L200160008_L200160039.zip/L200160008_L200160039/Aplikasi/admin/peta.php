<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Posting</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
   
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <!-- TABLE STYLES-->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>

    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2>Peta Tempat Wisata</h2>   
                </div>
                </div>
                <!-- /. ROW  -->
                <hr />
               
                                    
						<!-- Striped Tables -->
						<div class="panel panel-default">
                        <div class="panel-heading">
							<a href="index.php" class="btn btn-danger">Kembali</a>&nbsp;&nbsp;&nbsp;
							<a href="insertpeta.php"><button class="btn btn-primary"><i class="fa fa-edit "></i> Tambahkan Peta</button></a>
                        </div>
                        <div class="panel-body"><form method="get" name="posting" action="post.php">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>ID Lokasi</th>
											<th>ID Post</th>
                                            <th>Nama Lokasi</th>
                                            <th>Lat</th>
                                            <th>Long</th>
											<th>Aksi</th>
                                        </tr>
                                    </thead>
									<tbody>
								<?php
								error_reporting(E_ALL ^ E_NOTICE);
								include "koneksi.php";
								$no = 1;
								$sql = "select * from lokasi";
								$query = mysqli_query($conn,$sql);
								while($data=mysqli_fetch_array($query)){
								echo "
									<tr>
										<td>$no</td>
										<td>$data[id_lokasi]</td>
										<td>$data[id_posting]</td>
										<td>$data[nama_lokasi]</td>
										<td>$data[lat]</td>
										<td>$data[lng]</td>
										<td>
										<a href='hapuspeta.php?del=$data[id_lokasi]'>Hapus</a> 
										| 
										<a href='updatepeta.php?upd=$data[id_lokasi]'>Ubah</a>
										</td>
									</tr>
									";
								$no++;
								}
								?>
								</tbody>
								</table>
							</div></form>
						</div>
					</div>
	</div>
	<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
