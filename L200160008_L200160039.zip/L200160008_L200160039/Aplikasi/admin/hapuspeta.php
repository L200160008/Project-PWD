<?php
include "koneksi.php";
$del = $_GET['del'];
$sql = "delete from lokasi where id_lokasi = '$del'";
$query = mysqli_query($conn,$sql);
if($query){
	?>
	<script>alert("Peta Berhasil Dihapus");
	document.location="peta.php"
	</script>
	<?php
}
?>