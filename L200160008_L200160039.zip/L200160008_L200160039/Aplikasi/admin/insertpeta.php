<?php include('aksesadmin.php'); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Ubah Tempat Wisata</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
	<div class="container">
        <div class="row text-center ">
            <div class="col-md-12">
                <br /><br />
                <h2> Masukkan Lokasi Tempat Wisata</h2>
                <br/>
				<br/>
            </div>
        </div>
		<div class="row ">
                <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
				<a href="peta.php" class="btn btn-danger">Kembali</a>
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Masukkan Data
                        </div>
                        <div class="panel-body">
                            <h3></h3>
                            <form method="post" name="insertpeta" action="insertpeta.php">
                                    <div class="form-group">
                                        <label>ID Post</label>
										<input class="form-control" name="id">
                                    </div>
									<hr>
									<div class="form-group">
                                        <label>Nama Lokasi</label>
										<input class="form-control" name="nama">
                                    </div>
									<hr>
									<div class="form-group">
                                        <label>Latitude</label>
										<input class="form-control" name="lat">
                                    </div>
									<hr>
									<div class="form-group">
                                        <label>Longitude</label>
                                        <input class="form-control" name="lng">
                                    </div>
								
								</div>
								<div class="panel-footer">
								<input type="submit" class="btn btn-primary" name="submit" value="Submit">
								<input type="reset" class="btn btn-default" name="reset" value="Reset">
							</form>
							<?php
								error_reporting(E_ALL ^ E_NOTICE);
								$id = $_POST['id'];
								$nama = $_POST['nama'];
								$lat = $_POST['lat'];
								$lng = $_POST['lng'];
								$submit = $_POST['submit'];
								
								if($submit){
									include "koneksi.php";
									$kueri = "insert into lokasi(id_lokasi,id_posting,nama_lokasi,lat,lng)
									values('','$id','$nama','$lat','$lng')";
									$run = mysqli_query($conn,$kueri);
									if($run){
										?>
										<script>alert("Lokasi Berhasil Ditambahkan");
										document.location = 'peta.php'
										</script>
										<?php
									}
								}
								?>
                        </div>
                    </div>
                </div>
        </div>
		<!-- /. ROW  -->
		</div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>