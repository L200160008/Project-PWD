<?php
include "koneksi.php";
$hapus = $_GET['hapus'];
$sql = "delete from komentar where id_komentar = '$hapus'";
$query = mysqli_query($conn,$sql);
if($query){
	?>
	<script>alert("Komentar Berhasil Dihapus");
	document.location="komentar.php"
	</script>
	<?php
}
?>