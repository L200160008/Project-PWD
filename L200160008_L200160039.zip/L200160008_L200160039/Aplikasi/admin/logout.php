<?php
session_start();
session_destroy();
?>
<script language script="JavaScript">alert('Terima Kasih Atas Kunjungannya');
document.location='../index.php';</script>