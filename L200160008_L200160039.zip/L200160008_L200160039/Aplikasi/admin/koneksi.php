<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'wonogiri';

$conn = mysqli_connect($host,$user,$pass,$db) or die();
?>