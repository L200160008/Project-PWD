<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
$status = $_SESSION['status'];
if($status != "admin"){
	echo "<script language='javascript'>alert('Anda Bukan Admin, Dilarang Mengakses Halaman ini!'); 
	document.location='../login.php';</script>";
}
?>