-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2018 at 08:50 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wonogiri`
--

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
`id_komentar` int(11) NOT NULL,
  `username_user` varchar(11) NOT NULL,
  `id_posting` varchar(11) NOT NULL,
  `isi_komentar` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `komentar`
--

INSERT INTO `komentar` (`id_komentar`, `username_user`, `id_posting`, `isi_komentar`) VALUES
(1, 'Eileen', '1', 'Pemandangannya yang bikin jatuh hati, tempatnya enak anginnya semilir. Bikin kangen kalo di wonogiri.'),
(2, 'Eileen', '2', 'keren , hanya fasilitas yang kurang , tidak tersedia atm , mini market pun belum tersedia seru banget wisata kesini, pantai nya indah bayar nya murah juga, banyak turis mancanegara disana'),
(3, 'Eileen', '3', 'Tempat yang bagus untuk sekedar foto foto .. untuk Tiket masuk 10rb (sudah termasuk free minuman) .. cocok untuk duduk santai di siang yang terik .. Jalan menuju lokasi tidak sulit ditemukan, untuk penguna roda empat bisa ikuti saja google maps ..'),
(4, 'eka', '4', 'Tempatnya bagus, pemandangannya indah, ga perlu waktu lama untuk sampe ke puncak, tapi biasanya di puncak ada kawanan monyetnya, sampai di atas rasa lelah akan terbayar dengan pemandangan yang menakjubkan'),
(5, 'eka', '5', 'Viewnya bagus.  Tempat yang lumayan kece untuk melihat wonogiri sebelah timur.  Tapi kalau mau ke sini ada baiknya pagi atau sore hari.  Karena siang panas.'),
(6, 'eka', '6', 'Objek wisata andalan di wonogiri,dengan view waduk gajah mungkur yang sangat keren,lebih bagus pas sore hari saat menjelang magrib(sunset)'),
(7, 'gent', '7', 'Amazing place'),
(8, 'gent', '8', 'Tempat yang keren . Asri . Belum begitu rame . Sejuk . Jalan menuju kesana aspal halus sampai retribusi, disambung jalan cor, & jalan setapak menuju air terjun .'),
(9, 'gent', '9', 'Tempat yang luar biasa, puncak batu datar dengan pemandangan sekitar yang sangat menakjubkan, anugerah dari Sang Pencipta untuk Wonogiri tercinta, semoga dapat terawat keasriannya dan marilah kita menjaganya.'),
(10, 'gerda', '10', 'Tempat nyaman buat nyantai'),
(11, 'gerda', '11', 'Air terjun yang sangat indah. Airnya sejuk, dengan aliran air yang deras ketika musim hujan.'),
(12, 'gerda', '12', 'Pemandangan alam dan pegunungan cukup indah, masih sangat alami, udara sejuk. Akses jalan mudah dijangkau. Fasilitas mushola ada. '),
(13, 'helga', '13', 'Pesona pantai yang indah. Dengan pemandangan yang sangat alami'),
(14, 'helga', '14', 'Air Terjun Watu Jadah ini memang lain daripada yang lain, karena bebatuannya seperti batu yang tertata.\r\nSerta pemandangan yang masih sangat alami membuat kita bisa merefresh otak kita.'),
(15, 'gerda', '15', 'View indah'),
(16, 'helga', '16', 'Tempatnya bagus dan indah, cuman sayang akses buat ke air terjunnya masih susah, harus jalan kaki, tapi lelah terbayar dengan pemandangan nya'),
(17, 'helga', '17', 'Suka bgt...'),
(18, 'helga', '18', 'Bagus pemandangannya,menghadap kearah bukit gendol dan gunung lawu. Kalau pagi terlihat indah dikelilingi kabut.'),
(19, 'hernando', '19', 'Adem.... menyejukkan.... bisa buat refresh badan & fikiran.....'),
(20, 'hernando', '20', 'Tempat yang sangat nyaman dan asri. Terletak di kecamatan pracimantoro yang masih penuh dengan rerindangan pohon. Tiket masuknya juga sangat terjangkau. Disini kita bisa belajar mengenai sejarah masa lampau, baik sejarah nenek moyang, ...'),
(21, 'hernando', '21', 'Keren..Rasa lelah jalan kaki kesini terbayarkan karena indahnya'),
(22, 'hoshi', '22', 'Pemandangannya sangat bagus, kita bisa lihat hamparan waduk gajah mungkur wonogiri dari atas sini, kumpulan karamba terlihat kayak pelabuhan dari sini, udaranya sejuk, bagus buat edukasi anak perihal paralayang...'),
(23, 'hoshi', '23', 'Tempatnya sangat baguss lumayan keren Mantap banget good. #Wonderfool wonogiri'),
(24, 'juliana', '24', 'Pemandanganna mantapzz...'),
(25, 'juliana', '25', 'Pantainya bagus bangettt'),
(26, 'julta', '26', 'Pemandangan dari puncak joglonya bagus'),
(27, 'julta', '27', 'Air terjunnya masih asri'),
(28, 'juwan', '28', 'Wisatawan bisa menikmati keunikan goa dengan ciri khas batu-batu menggantung.'),
(29, 'juwan', '29', 'Tempatnya adem pas buat refresing bersama keluarga.');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi`
--

CREATE TABLE IF NOT EXISTS `lokasi` (
`id_lokasi` int(11) NOT NULL,
  `id_posting` varchar(11) NOT NULL,
  `nama_lokasi` varchar(45) NOT NULL,
  `lat` varchar(50) NOT NULL,
  `lng` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lokasi`
--

INSERT INTO `lokasi` (`id_lokasi`, `id_posting`, `nama_lokasi`, `lat`, `lng`) VALUES
(1, '1', 'Waduk Gajah Mungkur Wonogiri', '-7.885066', '110.899768'),
(2, '2', 'Pantai Nampu', '-8.210428', '110.903529'),
(3, '3', 'Telaga Claket', '-7.758055', '110.908025'),
(4, '4', 'Bukit Cumbri', '-7.840660', '111.305925'),
(5, '5', 'Puncak Secokro', '-7.815626', '111.297439'),
(6, '6', 'Watu Cenik', '-7.850543', '110.913777'),
(7, '7', 'Gunung Brojo', '-7.849154', '111.228068'),
(8, '8', 'Wisata Girimanik - Air Terjun', '-7.724986', '111.169599'),
(9, '9', 'Gunung Besek', '-7.921051', '111.216061'),
(10, '10', 'Hutan Pinus Bukit Suwondo', '-7.861144', '110.876655'),
(11, '11', 'Air Terjun Sanginan', '-7.832842', '111.293351'),
(12, '12', 'Candi Muncar', '-7.716771', '111.147127'),
(13, '13', 'Pantai Sembukan', '-8.204208', '110.844455'),
(14, '14', 'Air Terjun Watu Jadah', '-7.733786', '111.159581'),
(15, '15', 'Gunung Gandul', '-7.815471', '110.915000'),
(16, '16', 'Air Terjun Selondo', '-7.819814', '111.279840'),
(17, '17', 'Jurug Kemukus', '-8.055118', '111.098519'),
(18, '18', 'Soko Langit', '-7.753047', '111.201975'),
(19, '19', 'Wonoasri Seper', '-7.756264', '111.148406'),
(20, '20', 'Museum Karst', '-8.041357', '110.783202'),
(21, '21', 'Air Tejun Banyu Nibo', '-7.895674', '110.777213'),
(22, '22', 'Papan Luncur Gantole', '-7.845203', '110.896332'),
(23, '23', 'Bukit Jonambang', '-7.997185', '110.949750'),
(24, '24', 'Air Terjun Seloresi', '-7.738162', '111.184711'),
(25, '25', 'Pantai Pringjono', '-8.211121', '110.899883'),
(26, '26', 'Puncak Joglo', '-7.845182', '110.896332'),
(27, '27', 'Air Terjun kalimas', '-7.764003', '110.946888'),
(28, '28', 'Goa Putri Kencono', '-8.019730', '110.793802'),
(29, '29', 'Goa Ngantap', '-8.080729', '110.904159');

-- --------------------------------------------------------

--
-- Table structure for table `posting`
--

CREATE TABLE IF NOT EXISTS `posting` (
`id_posting` int(11) NOT NULL,
  `username_user` varchar(11) NOT NULL,
  `judul_posting` varchar(30) NOT NULL,
  `tanggal` varchar(20) NOT NULL,
  `gambar` varchar(50) NOT NULL,
  `isi_posting` varchar(5000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posting`
--

INSERT INTO `posting` (`id_posting`, `username_user`, `judul_posting`, `tanggal`, `gambar`, `isi_posting`) VALUES
(1, 'gibran', 'Waduk Gajah Mungkur Wonogiri', '01 Januari 2018', 'images/wgm.jpg', 'Wisata Waduk Gajah Mungkur di Sendang Wonogiri Jawa Tengah adalah salah satu tempat wisata yang berada di desa sendang, kabupaten wonogiri, provinsi  jawa tengah, negara indonesia. Wisata Waduk Gajah Mungkur di Sendang Wonogiri Jawa Tengah adalah tempat wisata yang ramai dengan wisatawan pada hari biasa maupun hari liburan. Tempat ini sangat indah dan bisa memberikan sensasi yang berbeda dengan aktivitas kita sehari hari.\r\nWisata Waduk Gajah Mungkur di Sendang Wonogiri Jawa Tengah sangat cocok untuk mengisi kegiatan liburan anda, apalagi saat liburan panjang seperti libur nasional, ataupun hari ibur lainnya.  Keindahan Wisata Waduk Gajah Mungkur di Sendang Wonogiri Jawa Tengah ini sangatlah baik bagi anda semua yang berada di dekat  atau di kejauhan untuk merapat mengunjungi tempat  Wisata Waduk Gajah Mungkur di Sendang Wonogiri Jawa Tengah di kota wonogiri.'),
(2, 'gibran', 'Pantai Nampu', '02 Januari 2018', 'images/nampu.jpg', 'Pantai Nampu adalah pantai pasir putih yang dihiasi oleh airnya yang biru kehijauan dan karang-karang yang menakjubkan. Pantai Nampu menajdi salah satu primadona pantai di Wonogiri. Akses jalan menuju Pantai Nampu sangat mudah dan bisa dilewati oleh bis dan kendaraan pribadi. Petunjuk jalannya pun sangat mudah. Masih di Kecamatan Paranggupito, jika Anda melihat peta wisata Wonogiri, maka Anda akan melihat bahwa didekat Pantai Banyutowo terdapat Pantai Nampu yang harus Anda kunjungi. Ini adalah pantai yang tidak boleh Anda lewatkan jika sedang berada di Pantai Banyutowo.'),
(3, 'gibran', 'Telaga Claket', '03 Januari 2018', 'images/claket.jpg', 'Telaga Claket terletak di Desa Sendang Ijo, Kecamatan Selogiri, Kabupaten Wonogiri, Jawa Tengah. Letaknya dekat dengan Bendungan Colo yang terletak di Kecamatan Nguter. Untuk akses menuju Telaga ini cukup mudah yaitu dari jalan raya Sukoharjo-Wonogiri (Tepatnya Pasar Jamu Nguter, Sukoharjo) kurang lebih 20 menit dengan menggunakan kendaraan sampai ke lokasi tersebut. Dikelilingi oleh bukit-bukit Telaga Claket ibarat surga yang tersembunyi dan masih natural menyatu dengan alam. Suasana hening bernafaskan hembusan angin membawa Kami merasa nyaman duduk di area Gazebo telaga sebelum turun ke telaga untuk mengambil gambar moment teristimewa.'),
(4, 'gibran', 'Bukit Cumbri', '04 Januari 2018', 'images/cumbri.jpg', 'Wisata Bukit Cumbri Wisata Baru-baru ini warga wonogiri sering mengunggah salah satu tempat yang bisa dibilang cukup indah dan eksotis sehingga membuat para pengguna media social merasa penasaran dan ingin mencoba berada disitu. Nama dari tempat yang sedang firal ini adalah Bukti Cumbri adalah tempat yang memiliki panorama alam yang sangat indah dan dapat membius mata setiap siapa saja yang dating apalagi ditempat ini juga biasa dijadikan sebagai spot untuk melihat sunrise ataupun sunset. Bukit Cumbri sendiri berada di Desa Kapyar, Kecamatan Purwantoro, Kabupaten Wonogiri, Provinsi Jawa Tengah. Biaya masuk kesini sangat murah, hanya Rp. 3.000 saja.'),
(5, 'gibran', 'Puncak Secokro', '05 Januari 2018', 'images/secokro.jpg', 'Wisata Bukit Secokro tempat wisata ini merupakan salah satu destinasi wisata alam yang ada di Wonogiri. Alamat berada di Desa Bakalan, Kecamatan Purwantoro, Kabupaten Wonogiri. Tempat wisata ini menawarkan pemandangan alam yang begitu indah dan mempesona sangat cocok untuk dijadikan tempat refreshing.. Selain itu juga pengelola menambahkan beberapa gardu pandang yang dapat dimanfaatkan oleh pengunjung untuk mengabadikan dengan berfotoria, sehingga menjadikan tempat ini sebagai wahana baru bagi para pemuda untuk melalukan selfie dengan berlatar belakang pemandang yang sangat indah.'),
(6, 'gibran', 'Watu Cenik', '06 Januari 2018', 'images/watucenik.jpg', 'Watu Cenik, merupakan salah satu tempat wisata yang menawarkan pesona alam Kabupaten Wonogiri dari atas bukit. Dengan bentang alam yang beragam, dari hamparan perairan Waduk Gajah Mungkur Wonogiri berpadu dengan eloknya perbukitan seakan memanjakan mata memandang. \r\nWatu Cenik terletak di Desa Sendang Kecamatan Wonogiri atau perjalanan 15 menit dari Kota Wonogiri satu arah dengan lokasi Obyek Wisata Waduk Gajah Mungkur. \r\nAkses jalan cukup memadai dapat ditempuh dengan kendaraan mobil maupun sepeda motor. Namun diharapkan pengunjung dapat lebih berhati-hati menuju tempat wisata ini karena medan yang cukup sulit dan menanjak. '),
(7, 'gilang', 'Gunung Brojo', '07 Januari 2018', 'images/brojo.jpg', 'Wisata Bukit Brojo merupakan salah satu dari berbagai macam wisata yang ada di Kabupaten Wonogiri. Wisata ini merupakan wisata alam berupa sebuah bukit yang memiliki ketinggian yang cukup lumayan tinggi. Dengan ketinggian tersebut jika kita sudah sampe puncak maka kita bisa melihat daerah Purwantoro, Ponorogo, Madiun , Magetan dengan cukup jelas, apalagi di pagi hari saat matahari menampakkan wajah nya suasana yang tak pernah anda bayangkan akan bisa kita lihat dengan jelas maka suasana akan semakin indah. Lokasi dari Bukit Brojo ini berada di Jl. Pd. Banaran, RT. 3 / RW. 5, Desa Joho, Kecamatan Purwantoro, Kabupaten Wonogiri, Jawa Tengah'),
(8, 'gilang', 'Wisata Giri Manik - Air Terjun', '08 Januari 2018', 'images/girimanik.jpg', 'Wisata Air Terjun Setren Girimanik di Slogohimo Wonogiri Jawa Tengah adalah salah satu tempat wisata yang berada di desa girimanik, kabupaten wonogiri, provinsi jawa tengah, negara indonesia. Wisata Air Terjun Setren Girimanik di Slogohimo Wonogiri Jawa Tengah adalah tempat wisata yang ramai dengan wisatawan pada hari biasa maupun hari liburan. Tempat ini sangat indah dan bisa memberikan sensasi yang berbeda dengan aktivitas kita sehari hari.\r\n\r\nWisata Air Terjun Setren Girimanik di Slogohimo Wonogiri Jawa Tengah memiliki pesona keindahan yang sangat menarik untuk dikunjungi. Sangat di sayangkan jika anda berada di kota wonogiri tidak mengunjungi wisata alam yang mempunyai keindahan yang tiada duanya tersebut.\r\n\r\nWisata Air Terjun Setren Girimanik di Slogohimo Wonogiri Jawa Tengah sangat cocok untuk mengisi kegiatan liburan anda, apalagi saat liburan panjang seperti libur nasional, ataupun hari ibur lainnya.  Keindahan Wisata Air Terjun Setren Girimanik di Slogohimo Wonogiri Jawa Tengah ini sangatlah baik bagi anda semua yang berada di dekat  atau di kejauhan untuk merapat mengunjungi tempat  Wisata Air Terjun Setren Girimanik di Slogohimo Wonogiri Jawa Tengah di kota wonogiri.'),
(9, 'gilang', 'Gunung Besek', '09 Januari 2018', 'images/besek.jpg', 'Gunung Besek menghadirkan landscape yang keren dan ekstrem. Karena gunung ini berupa bebatuan yang tampak menjorok seperti tebing dengan pemandangan hijau khas Pegunungan Kismantoro. View dari atas sendiri akan terlihat awan bertumpuk-tumpuk jika cuaca mendukung. Dari atas bebatuan tadi kita bisa menyaksikan sunset dan sunrise yang indah dan berkelas. Obyek wisata ini memang memiliki pesona yang menawan dengan puncak gunung dan pemandangan atau panorama alam yang indah disekililingnya, serta balutan gumpalan awan mapun kabut diatasnya disertai udara yang sejuk dan segar, sehingga tidak mengherankan jika tempat ini banyak dikunjungi oleh para wisatawan, khususnya kawula muda untuk memacu andrenalin, menapaki bebatuan menuju puncak Gunung Besek. Dari bebatuan besar itu kita akan bisa melihat alam sekitar yang sangat indah dari ketinggian.'),
(10, 'gilang', 'Hutan Pinus Bukit Suwondo', '10 Januari 2018', 'images/suwondo.jpg', 'Wisata Hutan pinus Gumuwang Wuryantoro Wonogiri terletak di desa Suwondo. Tempat wisata ini memang mungkin belum seterkenal hutan pinus yang ada di magelang atau yang ada di Jogja tetapi tempat ini sebetulnya juga tidak kalah dengan hutan pinus yang sudah sayasebutkan tadi, ditempat ini biasa juga dijadikan pilihan untuk foto priwedding banyak sekali yang sudah melakukannya dan tidak di pungut biaya juga. Disini cukup menjaga lingkungan agar tetap bersih udara segar,apalagi disiang hari terasa sejuk .'),
(11, 'gilang', 'Air Terjun Sanginan', '11 Januari 2018', 'images/sanginan.jpg', 'Pada Kecamatan Purwantoro ini ada sebuah desitanasi wisata yang tak kalah indahnya dengan wisata yang lainnya, namanya adalah Air terjun sanginan, sebuah air terjun yang dengan menawarkan kejernihan, udara yang sejuk, hijaunya alam dengan dikelilingi tebing megah. Air terjun sanginan ini sebelumnya juga di manfaatkan warga sekitar sebagai sumber mata air, pada musim libur air terjun ini juga dijadikan tempat rekreasi dan hiking para wisatawan dari dalam daerah maupun luar daerah purwantoro. Oh iya, kami sarankan jika anda mau datang ke air terjun sanginan ini pada musim penghujan atau pas musim penghujan beralih ke musim kemarau, karena air terjun ini sebenarnya air terjun musiman.'),
(12, 'gilang', 'Candi Muncar', '12 Januari 2018', 'images/muncar.JPG', 'Wisata yang satu ini belum begitu terkenal karena wisata ini masih dalam pembangunan yang di lakukan oleh pemerintah wonogiri,wisata ini terletak di bubaklan,girimarto,wonogiri,jawa tengah.tepatnya di ujung desa siroto. Wisata alam ini menyuguhi pemandangan alam yang sangat asri dan sejuk. Candi yang satu ini berbeda dengan candi yang lain,beda dengan candi biasanya yang berupa bangunan sejarah seperti candi prambanan dan candi borobudur.candi ini berupa tumpukan batu yang berbentuk seperti candi.  \r\nDi candi muncar ini terdapat telaga yang dijadikan pusat utama wisata ini.Candi muncar ini mempunyai 3 air terjun yang terdapat pada hulu telaga muncar ini. Udara yang sangat sejuk dan pemandangan yang alami membuat para pengunjung merasa sangat senang dan bahagia. Air yang masih alami membuat banyak pengunjung tertarik untuk berenang di telaga tersebut,di telaga tersebut disediakan gethek yang dibuat oleh pemuda siroto untuk para pengunjung agar bisa mengarungi telaga tersebut.'),
(13, 'adara', 'Pantai Sembukan', '13 Januari 2018', 'images/sembukan.jpg', 'Pantai Sembukan merupakansalah satu objek wisata yang ada di Kabupaten Wonogiri yang paling sering dikunjungi oleh para wisatawan. Pantai Sembukan berada di Kecamatan Paranggupito, Kabupaten Wonogiri, Provinsi Jawa Tengah. Pantai Sembukan memiliki air laut yang berwarna biru jernih dan bersih, pemandangan alam di sekitar pantai juga sangat indah sehingga bisa menghipnotis mata kalian. Selain menimati suasana pantai kalian juga bisa melakukan kegiatan berfotoria.'),
(14, 'adara', 'Air Terjun Watu Jadah', '14 Januari 2018', 'images/watujadah.JPG', 'Wisata Air Terjun Binangun Watu Jadah di Girimulyo Wonogiri Jawa Tengah adalah salah satu tempat wisata yang berada di desa girimulyo, kabupaten wonogiri, provinsi jawa tengah, negara indonesia. Wisata Air Terjun Binangun Watu Jadah di Girimulyo Wonogiri Jawa Tengah adalah tempat wisata yang ramai dengan wisatawan pada hari biasa maupun hari liburan. Tempat ini sangat indah dan bisa memberikan sensasi yang berbeda dengan aktivitas kita sehari hari.\r\nWisata Air Terjun Binangun Watu Jadah di Girimulyo Wonogiri Jawa Tengah memiliki pesona keindahan yang sangat menarik untuk dikunjungi. Sangat di sayangkan jika anda berada di kota wonogiri tidak mengunjungi wisata alam yang mempunyai keindahan yang tiada duanya tersebut.'),
(15, 'adara', 'Gunung Gandul ', '15 Januari 2018', 'images/Gunung-gandul.jpg', 'Gunung Gandul termasuk gugusan gunung seribu terletak di Kelurahan Giriwono, Kabupaten Wonogiri yang berjarak kira-kira 3 km dari pusat kota atau kurang labih 15 menit jika ditempuh perjalanan darat. Selama perjalanan menuju puncak Gunung Gandul, kita disuguhi oleh pemandangan alam yang masih hijau dan berbagai jenis pepohonan juga ada di sini. Jika kita sudah mencapai puncak gunung maka sajian pemandangan luas dapat kita nikmati. Dari puncak kita dapat melihat pemandangan Kota Wonogiri dan Waduk Gajah Mungkur nan indah.'),
(16, 'adara', 'Air Terjun Selondo', '16 Januari 2018', 'images/selondo.jpg', 'Grojogan Selondo adalah sebuah lokasi wisata alam yang berada di salah satu sudut Desa Bakalan. Desa tersebut terletak di Kecamatan Purwantoro, Kabupaten Wonogori, Provinsi Jawa Tengah. Letak Grojogan Selondo tersebut berada di sebuah ceruk di antara dua tebing batu. Dua kolam kecil dan sungai di bagian bawahnya sering dijadikan tempat nongkrong para wisatawan. Seorang blogger menilai pemandangan Grojogan Selondo layaknya versi mini dari Grand Canyon.'),
(17, 'adara', 'Jurug Kemukus', '17 Januari 2018', 'images/kemukus.jpg', 'Air Terjun Jurug Kemukus di Dusun Ngijo, Desa Purwoharjo, Kecamatan Karangtengah, Kabupaten Wonogiri, Jawa Tengah. Air Terjun Kemukus ini masih sangat alami dan memiliki panorama alam nan indah. Ekosistem alam sekitar air terjun tersebut juga masih sangat terjaga. Air Terjun Jurug Kemukus memiliki tiga tingkat. Tingkat paling atas, memiliki tinggi sekitar 30 meter yang diapit oleh tebing bebatuan yang tinggi dan terjal, sehingga angin disertai uap air berembus kencang menembus celah tebing. Tingkat kedua dan ketiga, masing-masing air terjun memiliki tinggi sekitar 40 meter. Air terjun kedua dan ketiga ini juga diapit oleh tebing sungai.'),
(18, 'adara', 'Soko Langit', '18 Januari 2018', 'images/sokolangit.jpg', 'Soko Langit terletak di Dusun Nglarangan, Desa Conto, Kec. Bulukerto, Kab. Wonogiri, Jawa Tengah. Soko Langit ini merupakan destinasi wisata di Wonogiri yang menawarkan pesona kolam renang dengan latar belakang alam hijau khas bebukitan. Yang membedakan kolam renang Soko Langit dan kolam renang lainnya yaitu lokasinya yang berada di kawasan bebukitan dengan udara yang menyejukan. Di sini juga tersedia wahana flying fox, gardu pandang, gazebo, dan sejumlah spot foto instagenik. Lokasinya yang jauh dari kehidupan kota membuat obyek wisata satu ini cocok untuk dijadikan tempat menenangkan diri. Ditambah lagi udaranya yang sejuk dan pemandangan alam sekitar yang begitu asri nan epic, tentu jadi daya tarik tersendiri bagi siapapun yang berkunjung kesini.'),
(19, 'haidar', 'Wonoasri Seper', '19 Januari 2018', 'images/seper.jpg', 'Wonoasri seper merupakan salah satu wisata alam di Wonogiri. Berada di lahan milik perhutani yang dikembangkan bersama warga sekitar dengan melibatkan infestor lokal,hutan pinus ini disulap menjadi tempat rekreasi yang menyenangkan. Wahana permainan di hutan objek wisata ini memang ada seperti flying fox yang memang di sediakan bagi kalian mau dan tidak salah ada paket harga seperti outbond dan lain lain. Jangan khawatir bagi kalian yang mengajak anak anak untuk mengobati kejenuhan disana juga ada wahana permainan untuk anak - anak.'),
(20, 'haidar', 'Museum Karst', '20 Januari 2018', 'images/museum-karst.jpg', 'Museum Karst adalah museum yang berisi koleksi informasi dan contoh batuan kapur (Karst), terletak di Desa Gebangharjo, Kecamatan Pracimantoro, Wonogiri dinilai merupakan museum karst terbesar dan terunik di Indonesia, bahkan di Asia Tenggara. Bagi kalian yang hobi dengan wisata museum atau dengan dunia geografi atau ingin mengenalkan kepada anak tentang dunia geografi maka tak ada salahnya untuk mengunjungi tempat wisata ini.'),
(21, 'haidar', 'Air Terjun Banyu Nibo', '21 Januari 2018', 'images/banyunibo.JPG', 'Air terjun ini terletak di Dusun Ngluwur, Kepuhsari, Mayaran, Wonogiri, Jawa Tengah. Banyu Nibo artinya air yang jatuh dari ketinggian, karena memang air terjun ini jatuh dari ketinggian sekitar 50 meter dan langsung mengenai batu hitam besar yang berada tepat di bawahnya. Air terjun ini memang terletak di perbatasan dua provinsi,Jawa tengah dan jogjakarta Jalan yang dilalui memang tidak mudah mengingat rutenya yang harus melalui jalan berkelok-kelok. Karena untuk mencapai air terjun tersebut harus melalui pematang sawah dan mengitari bukit. Pada saat perjalanan tersebut, Anda bisa melihat bukit yang hijau dengan terasering yang terlihat indah dan menarik.'),
(22, 'haidar', 'Papan Luncur Gantole', '22 Januari 2018', 'images/paralayang.jpg', 'Dari atas bukit Gantole kita akan di suguhi panorama yang menakjubkan,hamparan luas waduk gajah mungkur dapat kita lihat dari atas sini.Sungguh pemandangan yang tidak akan kita jumpai melihat luasnya waduk gajah mungkur jika kita tidak berkunjung ke sini.Dan jika anda penggemar olahraga paralayang,di juga di sediakan papan luncur untuk olahraga ini.Tapi di ingat olahraga ini hanya untuk bernyali tinggi jadi coba-coba karena juga di perlukan keahlian khusus.Di sediakan dua tingkatan disini yaitu pada ketinggian 200 meter dan 400 meter.'),
(23, 'haidar', 'Bukit Jonambang', '23 Januari 2018', 'images/jonambang.jpg', 'Wisata Bukit Janambang mungkin tempat ini masih sedikit yang tau, karena masih jarang yang mempromosikan padahal jika berada di atas puncak bukit kalian dapat melihat indahnya pemandangan alam serta hamparan luasnya waduk gajah mungkur yang berada dibagian selatan dan bahkan jika cuaca cerah dapat melihat langsung pemandangan gunung Merapi. Selain itu juga masih ada hal menarik yang bias kalian eksplor dari tempat ini yaitu kalian bias menikmat keindahan sunset. Bukit jonambang ini sendiri terletak di desa Watuagung Kecamatan Baturetno Kabupaten wonogiri.'),
(24, 'adelia', 'Air Terjun Seloresi', '24 Januari 2018', 'images/seloresi.jpg', 'Wisata Air terjun seloresi salah satu objek wisata baru yang mungkin belum banyak orang yang mengetahuinya, padahal tempat wisata air terjun ini memiliki keunikan dan bias menjadi salah satu pilihan destinasi wisata yang ada di Wonogiri. Memang tempat ini masih dalam pengembangan infastruktur dan sarana sehingga belum terlalu maksimal. Air terjun seloresi ini memiliki ketinggian sekitar 50 m dengan debit air yang cukup lumayan deras. Obyek wisata air terjun Seloresi ini terdapat di Desa Setren Kecamatan Slogohimo, Kabupaten Wonogiri.'),
(25, 'adelia', 'Pantai Pringjono', '25 Januari 2018', 'images/pringjono.jpg', 'Wisata Pantai Pringjono Wonogiri merupakan salah satu kekayaan alam yang begitu mempesona karena pantai ini diapit oleh dua buah tebing dengan garis pantai yang sempit memanjang kurang dari 100 meter. Pemandangan pantai kecil ini mirip seperti kawasan pantai pribadi yang tertutup dan tersembunyi. Bebatuan karang banyak ditemukan di tepi atau bawah tebing. Hamparan pasir pantai berwarna putih dengan butiran pasir yang cukup halus. Sebagian area pasir pantai tertutup oleh tanaman liar yang tumbuh merambat. Pantai Pringjono Wonogiri merupakan kawasan pantai yang berada di Desa Gunturharjo, kecamatan Paranggupito, kabupaten Wonogiri, Jawa Tengah.'),
(26, 'adelia', 'Puncak Joglo', '26 Januari 2018', 'images/puncakjoglo.jpg', 'Berlokasi di Kembang, Kelurahan Sendang, Wonogiri, Jawa Tengah. Puncak Joglo merupakan destinasi hits di Wonogiri yang banyak diburu Wisatawan. Dari waisatan lokal, Madiun, Karanganyar, bahkan ada yang dari Sragen berkunjung ke tempat ini hanya untuk berburu selfie di Puncak. View menawan menghadap gunung Cancep menjadi andalan utama sembari menunggu terbenamnya matahari, tidak jarang bila banyak wisatawan yang menghabiskan waktu hingga menjelang sore hari.'),
(27, 'adelia', 'Air Terjun Kalimas', '27 Januari 2018', 'images/kalimas.png', 'Beretak di Dungsono, Wonokerto, Kec. Wonogiri, Kabupaten Wonogiri, Jawa Tengah. Air sekitar Air Terjun Kalimas sangat jernih dan berwarna kebiruan seperti air laut, dan mempunyai ketinggian sekitar 10 meter dan mempunyai lebar sekitar 15 meter. Lokasi Air Terjun Kalimas juga tidaklah susah untuk dijangkau karena hanya akan membutuhkan waktu sekitar 10 hingga 15 menit saja dari daerah Kota Wonogiri.'),
(28, 'ega', 'Goa Putri Kencono', '28 Januari 2018', 'images/kencono.jpg', 'Beralamat di Dusun Wonosobo, RT 3/RW 1, Desa Wonodadi, Kec. Pracimantoro, Wonogiri. Jam Operasional dari Senin-Minggu 08.00 - 15.30. Dengan menyusuri Goa Putri Kencono anda akan memasuki beberapa ruangan, dan akan menyaksikan pemandangan indah dari batu stalagmid dan stalagnit yang berkembang baik. Di dalam ruangan tabuhan sangat menarik dimana stalagmid dan stalagnit jika dipukul dengan tangan akan mengeluarkan bunyi bak gamelan.'),
(29, 'ega', 'Goa Ngantap', '29 Januari 2018', 'images/ngantap.jpg', 'Goa Ngantap adalah salah satu Goa yang terdapat di Kelurahan Bayemharjo, Kecamatan Giritontro, Kabupaten Wonogiri, Provinsi Jawa Tengah, Indonesia. Goa ini adalah salah satu gua tujuan wisatawan lokal di Kabupaten Wonogiri. Formasi stalagtit dan stalagmit yang indah terdapat di dalam goa ini. Wilayah Wonogiri memiliki hamparan karst yang cukup luas seperti daerah-daerah sekitarnya, sehingga wilayah ini juga memiliki potensi wisata goa yang cukup menarik.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(25) NOT NULL,
  `nama_lengkap` varchar(45) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `nama_lengkap`, `email`, `password`, `status`) VALUES
('3ka', 'Ega Makaila Magenta', 'ega@gmail.com', 'egaa', 'admin'),
('adara', 'Adara Fredella Ulani', 'adara@gmail.com', 'adaraa', 'admin'),
('adeliaza', 'Adelia Zahra', 'adelia@gmail.com', 'adeliaa', 'admin'),
('echa', 'Eileen Chaka', 'eileen@gmail.com', 'eileenn', 'pengunjung'),
('eka5', 'Eka Kaila Kalyani', 'eka@gmail.com', 'ekaa', 'pengunjung'),
('gent6', 'Gent Hilamovi', 'gent@gmail.com', 'gentt', 'pengunjung'),
('gerda7', 'Gerda Henning', 'gerda@gmail.com', 'gerdaa', 'pengunjung'),
('gibran8', 'Gibran Ahmad Ramadhan', 'gibran@gmail.com', 'gibrann', 'admin'),
('gilang9', 'Gilang Galia Gamadi', 'gilang@gmail.com', 'gilangg', 'admin'),
('haidar21', 'Haidar Musyaffa ', 'haidar@gmail.com', 'haidarr', 'admin'),
('helga11', 'Helga Gregor Mendel', 'helga@gmail.com', 'helgaa', 'pengunjung'),
('hernando87', 'Hernando Damion', 'hernando@gmail.com', 'hernandoo', 'pengunjung'),
('hoshiba', 'Hoshi Fajar Bahir', 'hoshi@gmail.com', 'hoshii', 'pengunjung'),
('juli', 'Juliana Calista', 'juliana@gmail.com', 'julianaa', 'pengunjung'),
('julta', 'Julta Adamma', 'julta@gmail.com', 'jultaa', 'pengunjung'),
('juwara', 'Juwan Rara Rasmini', 'juwan@gmail.com', 'juwann', 'pengunjung');

-- --------------------------------------------------------

--
-- Table structure for table `user_has_posting`
--

CREATE TABLE IF NOT EXISTS `user_has_posting` (
  `username_user` varchar(10) NOT NULL,
  `id_posting` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `komentar`
--
ALTER TABLE `komentar`
 ADD PRIMARY KEY (`id_komentar`);

--
-- Indexes for table `lokasi`
--
ALTER TABLE `lokasi`
 ADD PRIMARY KEY (`id_lokasi`);

--
-- Indexes for table `posting`
--
ALTER TABLE `posting`
 ADD PRIMARY KEY (`id_posting`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `komentar`
--
ALTER TABLE `komentar`
MODIFY `id_komentar` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `lokasi`
--
ALTER TABLE `lokasi`
MODIFY `id_lokasi` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `posting`
--
ALTER TABLE `posting`
MODIFY `id_posting` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
